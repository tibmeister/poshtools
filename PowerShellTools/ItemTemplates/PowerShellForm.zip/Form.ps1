﻿. (Join-Path $PSScriptRoot '$safeitemname$.designer.ps1')

$MainForm.ShowDialog()